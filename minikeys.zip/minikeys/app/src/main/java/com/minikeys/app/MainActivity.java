package com.minikeys.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

/** Setup screen: 3 steps, a test field, default language, reset position. */
public class MainActivity extends Activity {

    private TextView status;

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final SharedPreferences prefs = getSharedPreferences(KeysService.PREFS, MODE_PRIVATE);
        float dp = getResources().getDisplayMetrics().density;
        int pad = (int) (18 * dp);

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        scroll.addView(box);

        TextView title = new TextView(this);
        title.setText("MiniKeys");
        title.setTextSize(24);
        box.addView(title);

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, pad / 2, 0, pad / 2);
        box.addView(status);

        box.addView(button("1) Enable the keyboard", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        }));
        box.addView(button("2) Allow display over other apps", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        }));
        box.addView(button("3) Choose MiniKeys as the keyboard", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.showInputMethodPicker();
            }
        }));

        EditText test = new EditText(this);
        test.setHint("Tap here to test the keyboard");
        test.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(test);

        TextView lang = new TextView(this);
        lang.setText("Starting language:");
        lang.setPadding(0, pad / 2, 0, 0);
        box.addView(lang);
        RadioGroup group = new RadioGroup(this);
        RadioButton en = new RadioButton(this);
        en.setId(200);
        en.setText("English");
        RadioButton ar = new RadioButton(this);
        ar.setId(201);
        ar.setText("Arabic");
        group.addView(en);
        group.addView(ar);
        group.check(prefs.getBoolean(KeysService.KEY_ARABIC, false) ? 201 : 200);
        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int checkedId) {
                prefs.edit().putBoolean(KeysService.KEY_ARABIC, checkedId == 201).apply();
            }
        });
        box.addView(group);

        box.addView(button("Reset keyboard position and size", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().remove(KeysService.KEY_X).remove(KeysService.KEY_Y)
                        .remove(KeysService.KEY_W).remove(KeysService.KEY_H).apply();
            }
        }));

        box.addView(button("Delete all saved clips", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().remove("clips").apply();
            }
        }));

        TextView notes = new TextView(this);
        notes.setText("Move: drag the top strip. Resize: drag the orange corner (top right). "
                + "Kbd = go back to your other keyboard. Hide = close it.\n\n"
                + "Tr translates the selected text, or the current line, between English and "
                + "Arabic. Tap the strip above the keys to insert the result. Only that text is "
                + "sent, to api.mymemory.translated.net, and only when you press Tr "
                + "(never in password fields). The free service has a small daily limit.\n\n"
                + "Clip button (top strip): Copy / Cut / Paste / All, and saved clips. Copy and Cut "
                + "save the text here (up to 30 clips). Save keeps whatever is on the clipboard now. "
                + "Tap a clip to insert it, x deletes it. Clips stay on this phone only, are not "
                + "encrypted, and are never saved from password fields - don't save passwords.\n\n"
                + "This keyboard has no autocorrect, no suggestions and no learning.");
        notes.setPadding(0, pad, 0, 0);
        box.addView(notes);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_INPUT_METHODS);
        String current = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.DEFAULT_INPUT_METHOD);
        String pkg = getPackageName() + "/";
        boolean on = enabled != null && enabled.contains(pkg);
        boolean selected = current != null && current.contains(pkg);
        boolean overlay = Settings.canDrawOverlays(this);
        status.setText("1) Enabled: " + (on ? "yes" : "no")
                + "\n2) Display over apps: " + (overlay ? "yes" : "no")
                + "\n3) Selected keyboard: " + (selected ? "yes" : "no"));
    }
}
