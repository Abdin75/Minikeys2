package com.minikeys.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Html;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.nio.charset.StandardCharsets;

/**
 * MiniKeys: a tiny keyboard. The keys are drawn in a floating overlay window that you can move
 * and resize. No dictionary, no prediction, no learning, no background work.
 */
public class KeysService extends InputMethodService {

    static final String PREFS = "minikeys";
    static final String KEY_X = "x";
    static final String KEY_Y = "y";
    static final String KEY_W = "w";
    static final String KEY_H = "h";
    static final String KEY_ARABIC = "arabic";

    private static final int FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

    /** Invisible view inside the system keyboard window. Its height makes apps leave room. */
    private static final class Reserve extends View {
        int h = 1;

        Reserve(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            setMeasuredDimension(MeasureSpec.getSize(widthSpec), h);
        }

        void setReserved(int px) {
            if (px != h) {
                h = px;
                requestLayout();
            }
        }
    }

    private Context app;
    private WindowManager wm;
    private SharedPreferences prefs;
    private float dp;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private KeyboardView kv;
    private WindowManager.LayoutParams lp;
    private Reserve reserve;
    private EditorInfo info;
    private boolean plainField = true;
    private boolean toldAboutPermission;

    // saved clips (loaded only when needed, freed when the keyboard hides)
    private static final int MAX_CLIPS = 30;
    private static final int MAX_CLIP_CHARS = 2000;
    private static final String KEY_CLIPS = "clips";
    private final ArrayList<String> clips = new ArrayList<String>();
    private boolean clipsLoaded;

    // translation state
    private int requestId;
    private String translationSource;
    private boolean translationWasSelection;
    private String pendingTranslation;

    @Override
    public void onCreate() {
        super.onCreate();
        app = getApplicationContext();
        wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        dp = getResources().getDisplayMetrics().density;
    }

    // ------------------------------------------------------------------ system keyboard window

    @Override
    public View onCreateInputView() {
        reserve = new Reserve(this);
        return reserve;
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo attribute, boolean restarting) {
        super.onStartInputView(attribute, restarting);
        info = attribute;
        plainField = !isPassword(attribute);
        showKeyboard(!restarting);
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        hideKeyboard();
    }

    @Override
    public void onWindowShown() {
        super.onWindowShown();
        if (kv == null && info != null) {
            showKeyboard(true);
        }
    }

    @Override
    public void onWindowHidden() {
        super.onWindowHidden();
        hideKeyboard();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (kv != null) {
            clampBounds();
            update();
            updateReserve();
        }
    }

    @Override
    public void onDestroy() {
        hideKeyboard();
        super.onDestroy();
    }

    private static boolean isPassword(EditorInfo ei) {
        if (ei == null) {
            return false;
        }
        int cls = ei.inputType & InputType.TYPE_MASK_CLASS;
        int variation = ei.inputType & InputType.TYPE_MASK_VARIATION;
        if (cls == InputType.TYPE_CLASS_TEXT) {
            return variation == InputType.TYPE_TEXT_VARIATION_PASSWORD
                    || variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    || variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
        }
        if (cls == InputType.TYPE_CLASS_NUMBER) {
            return variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD;
        }
        return false;
    }

    private String enterLabel() {
        if (info == null) {
            return "Enter";
        }
        if ((info.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            return "Enter";
        }
        if ((info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) {
            return "Enter";
        }
        switch (info.imeOptions & EditorInfo.IME_MASK_ACTION) {
            case EditorInfo.IME_ACTION_GO:
                return "Go";
            case EditorInfo.IME_ACTION_SEARCH:
                return "Search";
            case EditorInfo.IME_ACTION_SEND:
                return "Send";
            case EditorInfo.IME_ACTION_NEXT:
                return "Next";
            case EditorInfo.IME_ACTION_DONE:
                return "Done";
            default:
                return "Enter";
        }
    }

    // ------------------------------------------------------------------ floating window

    private int realW;
    private int realH;

    private void refreshScreen() {
        DisplayMetrics m = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(m);
        realW = m.widthPixels;
        realH = m.heightPixels;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private int minW() {
        return Math.min((int) (260 * dp), realW);
    }

    private int minH() {
        return Math.min((int) (170 * dp), realH);
    }

    private void clampBounds() {
        refreshScreen();
        lp.width = clamp(lp.width, minW(), realW);
        lp.height = clamp(lp.height, minH(), (int) (realH * 0.8f));
        lp.x = clamp(lp.x, 0, realW - lp.width);
        lp.y = clamp(lp.y, 0, realH - lp.height);
    }

    private void showKeyboard(boolean resetLayer) {
        if (!Settings.canDrawOverlays(this)) {
            if (!toldAboutPermission) {
                toldAboutPermission = true;
                Toast.makeText(this, "MiniKeys: allow 'display over other apps' in the MiniKeys app",
                        Toast.LENGTH_LONG).show();
            }
            return;
        }
        boolean arabic = prefs.getBoolean(KEY_ARABIC, false);
        int startLayer = 0;
        if (info != null) {
            int cls = info.inputType & InputType.TYPE_MASK_CLASS;
            if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) {
                startLayer = 1;
            }
        }
        if (kv == null) {
            refreshScreen();
            DisplayMetrics m = app.getResources().getDisplayMetrics();
            int w = prefs.getInt(KEY_W, -1);
            int h = prefs.getInt(KEY_H, -1);
            int x = prefs.getInt(KEY_X, -1);
            int y = prefs.getInt(KEY_Y, -1);
            if (w < 0 || h < 0 || x < 0 || y < 0) {
                w = m.widthPixels;
                h = Math.min((int) (250 * dp), (int) (m.heightPixels * 0.5f));
                x = 0;
                y = m.heightPixels - h;
            }
            lp = new WindowManager.LayoutParams(w, h,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, FLAGS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            lp.x = x;
            lp.y = y;
            clampBounds();
            kv = new KeyboardView(app, this);
            kv.configure(arabic, startLayer, enterLabel(), plainField);
            wm.addView(kv, lp);
        } else if (resetLayer) {
            kv.configure(arabic, startLayer, enterLabel(), plainField);
        }
        updateReserve();
    }

    private void hideKeyboard() {
        requestId++; // forget any translation still in flight
        clips.clear();
        clipsLoaded = false;
        if (kv != null) {
            kv.release();
            try {
                wm.removeView(kv);
            } catch (RuntimeException ignored) {
                // already gone
            }
            kv = null;
        }
    }

    private void update() {
        if (kv != null) {
            try {
                wm.updateViewLayout(kv, lp);
            } catch (RuntimeException ignored) {
                // not attached
            }
        }
    }

    /** If the keyboard sits on the bottom edge, make apps leave room for it. */
    private void updateReserve() {
        if (reserve == null || lp == null) {
            return;
        }
        int appH = app.getResources().getDisplayMetrics().heightPixels;
        boolean docked = lp.y + lp.height >= appH - (int) (8 * dp);
        reserve.setReserved(docked ? lp.height : 1);
    }

    int winX() {
        return lp.x;
    }

    int winY() {
        return lp.y;
    }

    int winW() {
        return lp.width;
    }

    int winH() {
        return lp.height;
    }

    void moveTo(int x, int y) {
        if (kv == null) {
            return;
        }
        lp.x = clamp(x, 0, realW - lp.width);
        lp.y = clamp(y, 0, realH - lp.height);
        update();
    }

    /** Resize from the top-right corner: left edge and bottom edge stay where they are. */
    void resizeTopRight(int left, int bottom, int newW, int newH) {
        if (kv == null) {
            return;
        }
        lp.width = clamp(newW, minW(), realW - left);
        lp.height = clamp(newH, minH(), Math.min(bottom, (int) (realH * 0.8f)));
        lp.x = left;
        lp.y = bottom - lp.height;
        update();
    }

    void saveBounds() {
        if (lp == null) {
            return;
        }
        prefs.edit().putInt(KEY_X, lp.x).putInt(KEY_Y, lp.y)
                .putInt(KEY_W, lp.width).putInt(KEY_H, lp.height).apply();
        updateReserve();
    }

    void saveLanguage(boolean arabic) {
        prefs.edit().putBoolean(KEY_ARABIC, arabic).apply();
    }

    void hideByUser() {
        ui.post(new Runnable() {
            @Override
            public void run() {
                requestHideSelf(0);
                hideKeyboard();
            }
        });
    }

    void switchKeyboard() {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (!switchToPreviousInputMethod()) {
                    InputMethodManager imm =
                            (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.showInputMethodPicker();
                }
            }
        });
    }

    // ------------------------------------------------------------------ typing

    void type(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.commitText(s, 1);
        }
    }

    void backspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
    }

    void enter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        if (info != null
                && (info.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) == 0
                && (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            int action = info.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (action != EditorInfo.IME_ACTION_NONE
                    && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action);
                return;
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }

    // ------------------------------------------------------------------ translation (MyMemory, on demand only)

    private static boolean hasArabic(String s) {
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0x0600 && ch <= 0x06FF) {
                return true;
            }
        }
        return false;
    }

    private static int utf8Length(String s) {
        return s.getBytes(StandardCharsets.UTF_8).length;
    }

    void translate() {
        if (kv == null) {
            return;
        }
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        if (!plainField) {
            kv.setPreview("Translate is off in password fields", false);
            return;
        }
        String src;
        boolean selection = false;
        CharSequence sel = ic.getSelectedText(0);
        if (sel != null && sel.length() > 0) {
            src = sel.toString();
            selection = true;
            if (utf8Length(src) > 480) {
                kv.setPreview("Selection too long (max about 480 bytes)", false);
                return;
            }
        } else {
            CharSequence before = ic.getTextBeforeCursor(400, 0);
            String b = before == null ? "" : before.toString();
            int nl = b.lastIndexOf('\n');
            if (nl >= 0) {
                b = b.substring(nl + 1);
            }
            while (b.length() > 0 && utf8Length(b) > 480) {
                b = b.substring(1);
            }
            src = b;
        }
        if (src.trim().length() == 0) {
            kv.setPreview("Nothing to translate", false);
            return;
        }
        translationSource = src;
        translationWasSelection = selection;
        pendingTranslation = null;
        final int id = ++requestId;
        final String q = src;
        final String pair = hasArabic(src) ? "ar|en" : "en|ar";
        kv.setPreview("Translating...", false);
        new Thread(new Runnable() {
            @Override
            public void run() {
                String result = null;
                String error = null;
                HttpURLConnection c = null;
                try {
                    URL url = new URL("https://api.mymemory.translated.net/get?q="
                            + URLEncoder.encode(q, "UTF-8")
                            + "&langpair=" + URLEncoder.encode(pair, "UTF-8"));
                    c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(12000);
                    int code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while (in != null && (n = in.read(buf)) > 0 && out.size() < 65536) {
                        out.write(buf, 0, n);
                    }
                    JSONObject o = new JSONObject(out.toString("UTF-8"));
                    int status = o.optInt("responseStatus", code);
                    if (status == 200) {
                        String t = o.getJSONObject("responseData").getString("translatedText");
                        result = Html.fromHtml(t, Html.FROM_HTML_MODE_LEGACY).toString();
                    } else {
                        error = o.optString("responseDetails", "Error " + status);
                    }
                } catch (Exception e) {
                    error = "No connection or bad reply";
                } finally {
                    if (c != null) {
                        c.disconnect();
                    }
                }
                final String res = result;
                final String err = error;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (id != requestId || kv == null) {
                            return; // keyboard closed or a newer request started
                        }
                        if (res != null) {
                            pendingTranslation = res;
                            kv.setPreview(res, true);
                        } else {
                            kv.setPreview(err == null ? "Translation failed" : err, false);
                        }
                    }
                });
            }
        }).start();
    }

    /** Tap on the preview strip: replace the source text with the translation. */
    void applyPreview() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || pendingTranslation == null || translationSource == null || kv == null) {
            return;
        }
        boolean same;
        if (translationWasSelection) {
            CharSequence sel = ic.getSelectedText(0);
            same = sel != null && translationSource.contentEquals(sel);
        } else {
            CharSequence before = ic.getTextBeforeCursor(translationSource.length(), 0);
            same = before != null && translationSource.contentEquals(before);
        }
        if (!same) {
            kv.setPreview("Text changed - press Tr again", false);
            pendingTranslation = null;
            return;
        }
        ic.beginBatchEdit();
        if (!translationWasSelection) {
            ic.deleteSurroundingText(translationSource.length(), 0);
        }
        ic.commitText(pendingTranslation, 1);
        ic.endBatchEdit();
        pendingTranslation = null;
        kv.setPreview("", false);
    }

    // ------------------------------------------------------------------ copy / cut / paste / saved clips

    private void loadClips() {
        if (clipsLoaded) {
            return;
        }
        clipsLoaded = true;
        clips.clear();
        try {
            JSONArray a = new JSONArray(prefs.getString(KEY_CLIPS, "[]"));
            for (int i = 0; i < a.length(); i++) {
                clips.add(a.getString(i));
            }
        } catch (Exception ignored) {
            // corrupted data: start empty
        }
    }

    private void storeClips() {
        JSONArray a = new JSONArray();
        for (String c : clips) {
            a.put(c);
        }
        prefs.edit().putString(KEY_CLIPS, a.toString()).apply();
    }

    ArrayList<String> clipList() {
        loadClips();
        return clips;
    }

    private void addClip(String text) {
        loadClips();
        String t = text.length() > MAX_CLIP_CHARS ? text.substring(0, MAX_CLIP_CHARS) : text;
        if (t.trim().length() == 0) {
            return;
        }
        clips.remove(t);
        clips.add(0, t);
        while (clips.size() > MAX_CLIPS) {
            clips.remove(clips.size() - 1);
        }
        storeClips();
    }

    void removeClip(int index) {
        loadClips();
        if (index >= 0 && index < clips.size()) {
            clips.remove(index);
            storeClips();
        }
    }

    void clearClips() {
        loadClips();
        clips.clear();
        storeClips();
    }

    void insertClip(int index) {
        loadClips();
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && index >= 0 && index < clips.size()) {
            ic.commitText(clips.get(index), 1);
        }
    }

    private void note(String s) {
        if (kv != null) {
            kv.setPreview(s, false);
        }
    }

    private void setClipboard(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("MiniKeys", text));
    }

    /** Returns the system clipboard text, or null if empty or marked sensitive. */
    private String readClipboard(boolean refuseSensitive) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        ClipData d = cm.getPrimaryClip();
        if (d == null || d.getItemCount() == 0) {
            return null;
        }
        if (refuseSensitive && d.getDescription() != null) {
            android.os.PersistableBundle extras = d.getDescription().getExtras();
            if (extras != null && extras.getBoolean("android.content.extra.IS_SENSITIVE", false)) {
                return null;
            }
        }
        CharSequence t = d.getItemAt(0).coerceToText(this);
        return t == null ? null : t.toString();
    }

    /** 0 copy, 1 cut, 2 paste, 3 select all, 4 save the current clipboard. */
    void clipAction(int action) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || kv == null) {
            return;
        }
        if (action == 2) {
            String t = readClipboard(false);
            if (t == null || t.length() == 0) {
                note("Clipboard is empty");
            } else {
                ic.commitText(t, 1);
            }
            return;
        }
        if (!plainField) {
            note("Disabled in password fields");
            return;
        }
        if (action == 0 || action == 1) {
            CharSequence sel = ic.getSelectedText(0);
            if (sel == null || sel.length() == 0) {
                note("Select some text first");
                return;
            }
            String t = sel.toString();
            setClipboard(t);
            addClip(t);
            if (action == 1) {
                ic.commitText("", 1);
            }
            note(action == 1 ? "Cut and saved" : "Copied and saved");
            kv.refreshClips();
        } else if (action == 3) {
            ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
            if (et != null && et.text != null) {
                ic.setSelection(0, et.text.length());
            } else {
                ic.performContextMenuAction(android.R.id.selectAll);
            }
        } else if (action == 4) {
            String t = readClipboard(true);
            if (t == null || t.trim().length() == 0) {
                note("Nothing to save (empty or private)");
                return;
            }
            addClip(t);
            note("Saved");
            kv.refreshClips();
        }
    }
}
